export default {
    API_URL: 'http://localhost:4000',
    API_URL_UPLOAD_FILES1: 'http://localhost:4000/supports',
    // API_URL: 'http://localhost:4000',
    API_URL_UPLOAD_FILES: 'http://localhost:4000/UploadFiles',
    APP_URL: 'https://v2.vngserver.vn',
    CAPTCHA_KEY: '6LeGP90kAAAAAG2H739_ZgZkl7IGFDWncEqzIHgv',
    CAPTCHA_SECRET: '6LeGP90kAAAAAEN18cgT8NS6yzkovSdmusaJZRkX'
    
}
