export default {
    shopping: 'Mua hàng',
    cash: 'Giao dịch',
    ticket: 'Hỗ trợ',
    home: 'Thông báo chung',
}
