export default interface IUpdateCloudServer {
    _id?: string
    cloudServerName?: string
}
