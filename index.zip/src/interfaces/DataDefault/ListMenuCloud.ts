export const ListMenuCloud = [
    {
        optionId: 1,
        name: 'Danh sách Cloud Vps',
        isCloud: false,
        cloudId: '',
    },
    {
        optionId: 2,
        name: 'Cloud Server đã bị xoá',
        isCloud: false,
        cloudId: '',
    },
    {
        optionId: 3,
        name: 'Cloud Server sắp hết hạn',
        isCloud: false,
        cloudId: '',
    },
]
