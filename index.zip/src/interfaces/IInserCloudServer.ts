export default interface IInserCloudServer {
    _id?: string
    cloudServerName?: string
    password?: string
    port?: string
    user?: string
    area?: string
    operatingSystem?: string
    server?: string
    isShow?: boolean
    createdTime?: string
    autoBackup?: boolean
}
