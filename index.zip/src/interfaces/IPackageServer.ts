export default interface IPackageServer {
    _id?: number
    status: number
    name?: string
    isCheck?: boolean
}
