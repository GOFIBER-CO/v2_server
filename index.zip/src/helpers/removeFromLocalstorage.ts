export default function (key: string) {
    localStorage.removeItem(key)
}
