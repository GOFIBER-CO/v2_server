import '@/styles/components/BlurGlass.scss'

const BlurGlass: React.FC = () => {
    return <div className="blur-glass"></div>
}

export default BlurGlass
