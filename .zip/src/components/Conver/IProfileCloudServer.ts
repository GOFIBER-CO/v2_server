export default interface IProfileCloudServer {
    _id: number
    cloudServerName?: string
    password?: string
    port?: string
}
