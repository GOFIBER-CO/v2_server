const CreateUser = () => {
    return <div className=""></div>
}

export default CreateUser
