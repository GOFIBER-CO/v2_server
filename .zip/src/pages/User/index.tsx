const User = () => {
    return <div></div>
}

export default User
