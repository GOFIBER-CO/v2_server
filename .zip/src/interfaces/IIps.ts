export default interface Ip {
    _id?: string,
    ip: string,
    status: boolean,
}