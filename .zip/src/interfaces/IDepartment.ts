export default interface IDepartment {
    _id?: string
    code: string
    processingRoomName: string
    createdTime?: string
    updatedTime?: string
}
