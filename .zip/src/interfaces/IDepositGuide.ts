export default interface IDepositGuide {
    _id: string
    content: string
}
