export default interface IProcessingRoom {
    name: string
    code: string
    _id: string
    createdTime: string
    updatedTime: string
}
