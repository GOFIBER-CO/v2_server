export default interface IPrice{
    ram: number,
    cpu: number,
    ssd: number,
    _id?: string,
}