export default interface ISnapshots {
    _id?: string
    code?: string
    content?: string
    createdTime?: string
    status?: number
}
